<?php

namespace App\Controllers;
use \CodeIgniter\Controller;
use CodeIgniter\HTTP\Files\UploadedFile;
use App\Models\UserOfferModel;
class UserOffer extends BaseController
{
	public function index()
	{

        helper("form");
        $rules =[
            'files'=>[
                'rules' => 'uploaded[files.0]|is_image[files]',
                'label' => 'The File'
            ],

         ];

        $data = [];
        $noviId="";

        //$owner=$_SESSION["user"];
        $owner = 6;
        $nizslika = "";
        $userModel = new UserOfferModel();
        if($_POST){
            

            $naslov = $_POST["naslov"];
            $telefon = $_POST["telefon"];
            $cena = $_POST["cena"];
            $lokacija = $_POST["lokacija"];

            $pocetak = $_POST["pocetak"];
            $kraj = $_POST["kraj"];
            $opis = $_POST["opis"];

           date_default_timezone_set('Europe/Belgrade');
           $meseci=array(1 => "Jan",2 => "Feb",3 => "Mar",4 => "Apr",5 => "May",6 => "Jun",
                         7 => "Jul",8 => "Avg",9 => "Sep",10 => "Okt",11 => "Nov",12 => "Dec");
           if(!empty($pocetak) || !empty($kraj)){
                $deloviPocetka=explode(",",$pocetak);
                $godinaPocetak=$deloviPocetka[1];
                $drugiDeoPocetka=explode(" ",$deloviPocetka[0]);
                $mesecPocetak=$drugiDeoPocetka[0];
                $danPocetak=$drugiDeoPocetka[1];

                
                $deloviKraja=explode(",",$kraj);
                $godinaKraj=$deloviKraja[1];
                $drugiDeoKraja=explode(" ",$deloviKraja[0]);
                $mesecKraj=$drugiDeoKraja[0];
                $danKraj=$drugiDeoKraja[1];

                $mesP=array_search($mesecPocetak,$meseci);
                $mesK=array_search($mesecKraj,$meseci);

                if($mesP < 10) $mesP="0".$mesP;
                if($mesK < 10) $mesK="0".$mesK;

                $datumPocetak=$godinaPocetak."-".$mesP."-".$danPocetak." ".date("H").":".date("i").":".date("s");
                $datumKraj=$godinaKraj."-".$mesK."-".$danKraj." ".date("H").":".date("i").":".date("s");
           }
            $poruka = ""; $katego="";
            if(!empty($_POST['kat'])){ $katego=$_POST['kat']; }
            
           $jela=array();
            if(!empty($_POST['jelo'])){
                foreach($_POST['jelo'] as $report_id){
                array_push($jela,$report_id);
                }
            }
            
            if(empty($naslov)){
                $poruka = "Niste uneli naslov vase ponude";
            }
            else if(empty($telefon)){
                $poruka = "Niste uneli telefon za kontakt";
            }
            else if(!is_numeric($telefon)){
                $poruka = "Broj telefona moze sadrzati samo brojeve";
            }
            else if(empty($cena)){
                $poruka = "Niste uneli cenu vase ponude";
            }
            else if(empty($lokacija)){
                $poruka = "Niste uneli za lokaciju na koju se vasa ponuda odnosi";
            }
            else if(empty($pocetak)){
                $poruka = "Niste uneli pocetni datum";
            }
            else if($pocetak < date('M d,Y')){//maj 19,2021
                $poruka = "Datum pocetka je u proslosti";
                //echo $pocetak;
            }
            else if(empty($kraj)){
                $poruka = "Niste uneli krajnji datum";
            }
            else if($kraj < $pocetak){
                $poruka = "Krajnji datum ne sme biti u proslosti ili pre pocetnog datuma";
            }
            else if($katego == 0){
                $poruka = "Morate izabrati kategoriju";
            }
            else if(empty($opis)){
                $poruka = "Niste uneli opis vase ponude";
            }
            else if($this->validate($rules)){
                //$file = $this->request->getFiles('img');
                if($imagefile = $this->request->getFiles())
                {
                    $cnt = 0;
                   foreach($imagefile['files'] as $img)
                   {
                      if ($img->isValid() && ! $img->hasMoved())
                      {
                           $noviId=$userModel->getMaxId()+1;
                           $path = "./slike/".$noviId;
                           $img->move($path,$cnt.$img->getName());
                           $uBazi = $path."/".$img->getName();
                           $nizslika=$nizslika.$uBazi.";";
                           $cnt = $cnt + 1;
                      }
                   }
                }
            }
            else{
                $poruka = "Morate uneti slike i to u nekom od standardnih formata za slike";
            }

            $data["validacija"] = $poruka;

            if($poruka == ""){
                //sve je ispravno
                $tekstkategorije="";
                if($katego == 1){ $tekstkategorije = "More"; }
                if($katego == 2){ $tekstkategorije = "Planina"; }
                if($katego == 3){ $tekstkategorije = "Grad"; }
                if($katego == 4){ $tekstkategorije = "Selo"; }
                $dorucak = 0; $rucak = 0; $vecera = 0;
                if(!empty($jela[0])){
                    if($jela[0] == "on"){
                         $rucak = 1;
                        }
                }
                if(!empty($jela[1])){
                    if($jela[1] == "on"){
                         $rucak = 1;
                        }
                }
                if(!empty($jela[2])){
                    if($jela[2] == "on"){ 
                        $vecera = 1;
                    }
                }

                $userModel->addNewOffer($naslov, $noviId,$telefon, $cena, $lokacija,
                  $datumPocetak, $datumKraj, 0,0,$tekstkategorije, 0,0,0,$dorucak,
                  $rucak, $vecera, 0,0,0, $owner, "Na cekanju","0000-00-00 00:00:00",
                  $opis, $nizslika );
            }
        }

		return view('useroffer.php',$data);
	}
}