1.Sve se slike cuvaju u public folderu slike sa podfolderom id ponude
2.Nisam dodao proveru da ako prilikom izmene ponude dodaje iste slike u istom redosledu, inace ce da radi sve 
3.Sto se tice linkova ne znam gde da skocim nakon izvrsene operacije brisanja ili azuriranja, prema onome sto pise u nav baru za pregled
njegove ponude se opet vraca na stranicu za izmenu. To proveriti
4.Kategorija je obavezno polje
5.Kada pokusam preko php opet da postavim value za datum koji je u formatu May 25, 2021 on to ne dozvoljava zbog razmaka pa sam stavio
sa crticama ali ako treba da se sacuva promena to mora da se izabere iz kalendara. Stavio sam gresku za to kao potvrda datuma
6.Kad obrisem ponudu treba da obrisem i folder medjutim za sad nisam uspeo, to cu uraditi pa cu dodati --> trebalo bi da je to par linija koda
7.Kod kontakta mejl moze da salje onaj ko je dozvolio u podesavanjima za google nalog manje sigurne aplikacije i ko je uneo email adresu
i lozinku u klasi email. Ja sam tu uneo packandgo mail i saljem npr meni ali moze i na isti taj mejl pri cemu kao telo poruke prosledjujem
podatke koje je uneo korisnik. Jednostavno ne moze drugacije a da sam ja to nasao
8.Potrebno je otkomentarisati deo za dohvatanje korisnika iz sesije i dodeliti promenjlivoj owner ili kako se vec tu ispod zove, ja sam
to samo dohvatao iz sesije, nisam siguran da je to dobro
9.Published polje sam ostavio sa sve nulama jer je to valjda kada admin odobri treba tu da unese trenutni datum
10.Za start i end time je trenutno vreme a naravno ucitani datum sa kalendara
11.Sad sam se setio da treba da dodam jos i kad je prazna tabela ponuda u bazi proveru ---> to cu dodati
 