<?php

namespace App\Models;

use CodeIgniter\Model;

class AgencyOfferModel extends Model
{
    protected $table      = 'offer';
    protected $primaryKey = 'idOffer';

    //protected $useAutoIncrement = true;
    public function getMaxId(){
        //proveri ako je null
        $db = \Config\Database::connect();
        $podaci = $db->query('SELECT idOffer FROM offer ORDER BY idOffer DESC LIMIT 1');
        $row = $podaci->getRow();
        return $row->idOffer;

    }
    public function addNewOffer(
        $title, $idOffer, $phone, $price, $location,
        $startDate, $endDate, $transport, $accomodation,
        $category, $allInclusive, $insurance, $guide, 
        $breakfast, $lunch, $dinner, $trips, $internet,
        $AC, $owner, $status, $published, $description, $slike ) {


        $podaci = [
            'title'       =>   $title,
            'idOffer'     =>   $idOffer,
            'phone'       =>   $phone,
            'price'       =>   $price,
            'location'    =>   $location,
            'startDate'   =>   $startDate,
            'endDate'     =>   $endDate,
            'transport'   =>   $transport,
            'accomodation'=>   $accomodation,
            'category'    =>   $category,
            'allinclusive'=>   $allInclusive,
            'insurance'   =>   $insurance,
            'guide'       =>   $guide,
            'breakfast'   =>   $breakfast,
            'lunch'       =>   $lunch,
            'dinner'      =>   $dinner,
            'trips'       =>   $trips,
            'internet'    =>   $internet,
            'AC'          =>   $AC,
            'owner'       =>   $owner,
            'status'      =>   $status,
            'published'   =>   $published,
            'description' =>   $description,
            'pictures'    =>   $slike
        ];
        $db = \Config\Database::connect();
        $db->table('offer')->insert($podaci);
    }


}